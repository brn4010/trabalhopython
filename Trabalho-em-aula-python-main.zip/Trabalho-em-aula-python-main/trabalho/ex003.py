#Ex3: Acesso a índices inexistentes
lista = [1, 2, 3]
print(lista[4])
