#Ex5: Erros de Sintaxe (mais comuns)
while True print("Hello world")
