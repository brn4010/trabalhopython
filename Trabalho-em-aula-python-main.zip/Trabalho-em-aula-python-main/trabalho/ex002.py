#Ex2: Soma de tipos não suportados
10 + 'ae'
