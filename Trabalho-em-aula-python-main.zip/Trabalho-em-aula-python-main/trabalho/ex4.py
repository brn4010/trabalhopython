try:
    x = int(input('Enter number: '))
    x = x + 1
    print(x) 
except:
    print("invalid imput")
finally:
    print("valid input")