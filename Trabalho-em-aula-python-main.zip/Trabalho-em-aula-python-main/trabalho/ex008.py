#Ex8: Tentativa de operação de tipos diferentes
print(2 + '2')
