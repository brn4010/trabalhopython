#Ex6: Erros de nomes (variáveis) ou a falta delas.
4 + spam*3
