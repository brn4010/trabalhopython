#Ex9: Usar uma biblioteca que não foi invocada antes
print(math.sqrt(2))
