#Ex7: Tentativa de concatenação de tipos diferentes
print('2' + 2)
