#Ex11: Tentativa de abrir um arquivo para leitura
print("Abrindo um Arquivo!")
open("texto.txt", "r")
