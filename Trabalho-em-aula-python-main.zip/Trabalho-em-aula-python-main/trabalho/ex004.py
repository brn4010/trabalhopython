#Ex4: Acesso a chaves inexistente
dicionario = {1:"item 1", 2:"item 2"}
print(dicionario[5])
