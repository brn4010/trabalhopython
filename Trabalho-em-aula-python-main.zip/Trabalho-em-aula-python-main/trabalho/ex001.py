#Ex1: Divisão por Zero
num = 1/0
