#Ex10: Erros associados à cálculos matemáticos
import math
print(math.sqrt(-2))
